Disassembling
=============

To disassemble an MSP430 program:

    ./naken_util -disasm -msp430 launchpad_blink.hex


