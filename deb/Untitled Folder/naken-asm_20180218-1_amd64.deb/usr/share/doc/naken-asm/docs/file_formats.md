File Formats
============

naken_asm supports the following file formats:

Reading
-------

Intel Hex
SREC
binary
TI txt
WDC Binary

Writing
-------

Intel Hex
SREC
binary
WDC Binary

